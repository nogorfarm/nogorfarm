ALTER TABLE `shops` ADD `thermal_printer_width` INT NULL AFTER `bank_payment_status`;
COMMIT;